// Dismiss your keyboard when you are
// scrolling your tableView down interactively.
tableView.keyboardDismissMode = .interactive
