// Passing operator as closures
let array = [3, 9, 1, 4, 6, 2]
let sorted = array.sorted(by: >)
// [9, 6, 4, 3, 2, 1]