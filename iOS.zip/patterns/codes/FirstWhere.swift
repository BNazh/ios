// Use .first(where: (Int) throws -> Bool)
// to retrieve first elemen in an array which contains
// the same conditional objects.
let numbers = [3, 7, 4, -2, 9, -6, 10, 1]
if let firstNegative = numbers.first(where: { $0 < 0 }) {
    print("The first negative number is \(firstNegative).")
}
// Prints "The first negative number is -2."