// To enable security code autofill on a UITextField we need to set the textContentType property to .oneTimeCode.
otpTextField.textContentType = .oneTimeCode
