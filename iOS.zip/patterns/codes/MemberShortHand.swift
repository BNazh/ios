// UIColor.white
view.backgroundColor = .white
// CGRect.zero
view.frame = .zero
// You can address initializers this way too
tableView = .init(frame: .zero, style: .plain)