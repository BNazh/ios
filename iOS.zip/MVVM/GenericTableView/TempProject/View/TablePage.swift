//
//  TablePage.swift
//  TempProject
//
//  Created by Nazhmeddin on 2/14/19.
//  Copyright © 2019 Nazhmeddin. All rights reserved.
//

import UIKit
import SnapKit

class TablePage: UITableViewController {
    
    let viewModel = TableViewModel()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewSetup()
    }
    
    private func tableViewSetup() {
        tableView.estimatedRowHeight = 60
        tableView.tableFooterView = UIView()
        tableView.register(UserCell.self, forCellReuseIdentifier: UserCell.reuseIdentifier)
        tableView.register(MessageCell.self, forCellReuseIdentifier: MessageCell.reuseIdentifier)
        tableView.register(ImageCell.self, forCellReuseIdentifier: ImageCell.reuseIdentifier)
        tableView.register(WarningCell.self, forCellReuseIdentifier: WarningCell.reuseIdentifier)
    }
}

extension TablePage {
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.items.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = viewModel.items[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: type(of: item).reuseId, for: indexPath)
        item.configure(cell: cell)
        return cell
    }
}
