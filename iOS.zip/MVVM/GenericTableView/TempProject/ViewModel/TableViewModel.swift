//
//  TableViewModel.swift
//  TempProject
//
//  Created by Nazhmeddin on 2/14/19.
//  Copyright © 2019 Nazhmeddin. All rights reserved.
//

import Foundation

typealias UserCellConfigurator = TableCellConfigurator<UserCell, User>
typealias MessageCellConfigurator = TableCellConfigurator<MessageCell, String>
typealias ImageCellConfigurator = TableCellConfigurator<ImageCell, Picture>
typealias WarningCellConfigurator = TableCellConfigurator<WarningCell, String>

class TableViewModel {
    var items: [CellConfigurator] = []
    
    init() {
        items = [
            UserCellConfigurator.init(item: User(username: "Ilyar")),
            UserCellConfigurator.init(item: User(username: "Abay")),
            MessageCellConfigurator.init(item: "Salem!"),
            ImageCellConfigurator.init(item: Picture(color: #colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1))),
            ImageCellConfigurator.init(item: Picture(color: #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1))),
            WarningCellConfigurator.init(item: "ZZZzzzZZZzzzZZZzzz 😴")
        ]
    }
}
