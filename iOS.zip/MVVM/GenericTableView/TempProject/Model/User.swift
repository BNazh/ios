//
//  User.swift
//  TempProject
//
//  Created by Nazhmeddin on 2/14/19.
//  Copyright © 2019 Nazhmeddin. All rights reserved.
//

import Foundation

struct User {
    let username: String
}
