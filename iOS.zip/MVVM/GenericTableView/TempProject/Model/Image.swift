//
//  Image.swift
//  TempProject
//
//  Created by Nazhmeddin on 2/14/19.
//  Copyright © 2019 Nazhmeddin. All rights reserved.
//

import UIKit

struct Picture {
    let color: UIColor
}
