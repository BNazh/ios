# News

## Setup

1. Clone the repo
```bash
$ git clone https://github.com/danabeknar/News.git
$ cd News
```
2. Install dependencies from [CocoaPods](http://cocoapods.org/#install)
```bash
$ pod install
```
3. Open the Xcode workspace at `news-app.xcworkspace`.

